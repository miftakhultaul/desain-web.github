
    function tampilkanMenu() {
        var programStudi = document.getElementById("programStudi");
        var selectedOption = programStudi.options[programStudi.selectedIndex].value;

        // Sembunyikan semua menu
        var semuaMenu = document.querySelectorAll('div[id^="menu"]');
        for (var i = 0; i < semuaMenu.length; i++) {
            semuaMenu[i].style.display = "none";
        }

        // Tampilkan menu yang sesuai dengan pilihan program studi
        var menuYangDitampilkan = document.getElementById("menu" + selectedOption);
        menuYangDitampilkan.style.display = "block";
    }
